﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToleranceTask.Models
{
    public class ToleranceGridViewModel
    {
        public string ToleranceName { get; set; }
        public string Scenario { get; set; }
        public string Database { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
        public string DesignSolution { get; set; }
    }

}
