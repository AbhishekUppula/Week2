﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToleranceTask.Models
{
  public class ToleranceName
    {
        public string Name { get; set; } = string.Empty;
    }

    public class Status
    {
        public string Name { get; set; } = string.Empty;
    }
    public class DesignSolution
    {
        public string Name { get; set; }=   string.Empty;
    }

    public class ToleranceFilter
    {
        public string ToleranceName { get; set; } = string.Empty;
        public string StatusName { get;set; } = string.Empty;
        public string DSName { get; set; } = string.Empty;
    }

}
