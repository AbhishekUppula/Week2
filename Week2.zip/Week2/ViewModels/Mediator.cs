﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToleranceTask.ViewModels
{
    public class Mediator
    {
        private static readonly Mediator _instance = new Mediator();
        private readonly Dictionary<string, Action<object>> _subscriptions = new Dictionary<string, Action<object>>();

        public static Mediator Instance => _instance;

        public void Subscribe(string message, Action<object> action)
        {
            if (!_subscriptions.ContainsKey(message))
                _subscriptions.Add(message, null);

            _subscriptions[message] += action;
        }

        public void Unsubscribe(string message, Action<object> action)
        {
            if (_subscriptions.ContainsKey(message))
                _subscriptions[message] -= action;
        }

        public void Publish(string message, object data)
        {
            if (_subscriptions.ContainsKey(message))
                _subscriptions[message]?.Invoke(data);
        }
    }

}
