﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using ToleranceTask.Views;
using ToleranceTask.Models;
using IronXL;
using System.ComponentModel;
using System.Windows.Markup;
using static OfficeOpenXml.ExcelErrorValue;
using ExcelDataReader.Log;
using System.Buffers.Text;
using System.Collections;
using System.Reflection.Metadata;
using System.Windows.Automation;

namespace ToleranceTask.ViewModels
{
    public class ToleranceViewModel : INotifyPropertyChanged
    {
        public ICommand OpenGridWindowCommand { get; }
        public ObservableCollection<Models.ToleranceGridViewModel> ToleranceItems { get; set; }

        private DatabaseModel _receivedValue;

        private ToleranceFilter _tolerancereceivedValue;


        public event PropertyChangedEventHandler? PropertyChanged;

        public event PropertyChangedEventHandler? PropertyChangedFilterChanges;

        public DatabaseModel ReceivedValue
        {
            get { return _receivedValue; }
            set
            {
                _receivedValue = value;
                OnPropertyChanged(ReceivedValue);
            }
        }

        public ToleranceFilter TolerranceFilter
        {
            get { return _tolerancereceivedValue; }
            set
            {
                _tolerancereceivedValue = value;
                OnPropertyChangedFilterChanges(TolerranceFilter);
            }
        }


        public ToleranceViewModel()
        {
            OpenGridWindowCommand = new RelayCommand(OpenGridWindow);
        }

        private void LoadExcelData(DatabaseModel Model)
        {
            // Replace with the path to your Excel file
            string filePath = "ToleranceTaskDB/ToleranceDB.xlsx";

            ToleranceItems = new ObservableCollection<ToleranceGridViewModel>();

            WorkBook workBook = WorkBook.Load(filePath);
            WorkSheet workSheet = workBook.WorkSheets[1];

            for(int i = 2;i<=51;i++)
            {
                IronXL.Cell Ccell = workSheet["C" + i].First();
                string DBName = Ccell.StringValue;
                if (DBName.ToLower() == Model.DBName.ToLower())
                {
                    IronXL.Cell Bcell = workSheet["B" + i].First();
                    string ToleranceName = Bcell.StringValue;

                    IronXL.Cell Dcell = workSheet["D" + i].First();
                    string Scenario = Dcell.StringValue;

                    IronXL.Cell Ecell = workSheet["E" + i].First();
                    string DesignSolution = Ecell.StringValue;


                    IronXL.Cell Fcell = workSheet["F" + i].First();
                    string Comments = Fcell.StringValue;


                    IronXL.Cell Gcell = workSheet["G" + i].First();
                    string Status = Gcell.StringValue;

                    ToleranceItems.Add(new ToleranceGridViewModel
                    {
                        ToleranceName = ToleranceName,
                        Database = DBName,
                        Status = Status,
                        Comments = Comments,
                        DesignSolution = DesignSolution,
                        Scenario = Scenario
                    });
                }
            }
        }

        private void LoadExcelFilterData(ToleranceFilter Model)
        {
            // Replace with the path to your Excel file
            string filePath = "ToleranceTaskDB/ToleranceDB.xlsx";

            ToleranceItems = new ObservableCollection<ToleranceGridViewModel>();

            var lToleranceItems = new ObservableCollection<ToleranceGridViewModel>();

            WorkBook workBook = WorkBook.Load(filePath);
            WorkSheet workSheet = workBook.WorkSheets[1];

            for (int i = 2; i <= 51; i++)
            {
                IronXL.Cell Ccell = workSheet["C" + i].First();
                string DBName = Ccell.StringValue;

                    IronXL.Cell Bcell = workSheet["B" + i].First();
                    string ToleranceName = Bcell.StringValue;

                    IronXL.Cell Dcell = workSheet["D" + i].First();
                    string Scenario = Dcell.StringValue;

                    IronXL.Cell Ecell = workSheet["E" + i].First();
                    string DesignSolution = Ecell.StringValue;


                    IronXL.Cell Fcell = workSheet["F" + i].First();
                    string Comments = Fcell.StringValue;


                    IronXL.Cell Gcell = workSheet["G" + i].First();
                    string Status = Gcell.StringValue;

                lToleranceItems.Add(new ToleranceGridViewModel
                    {
                        ToleranceName = ToleranceName,
                        Database = DBName,
                        Status = Status,
                        Comments = Comments,
                        DesignSolution = DesignSolution,
                        Scenario = Scenario
                    });
            }


            var filteredItems = lToleranceItems;

            if (!string.IsNullOrEmpty(Model.ToleranceName))
            {
                filteredItems = new ObservableCollection<ToleranceGridViewModel>(filteredItems.Where(x => x.ToleranceName == Model.ToleranceName));
            }

            if (!string.IsNullOrEmpty(Model.StatusName))
            {
                filteredItems = new ObservableCollection<ToleranceGridViewModel>(filteredItems.Where(x => x.Status == Model.StatusName));
            }

            if (!string.IsNullOrEmpty(Model.DSName))
            {
                filteredItems = new ObservableCollection<ToleranceGridViewModel>(filteredItems.Where(x => x.DesignSolution == Model.DSName));
            }
            ToleranceItems = new ObservableCollection<ToleranceGridViewModel>(filteredItems);
            
        }
        private void OpenGridWindow()
        {
            var newWindow = new ToleranceGridView();
            newWindow.Show();
        }
        private void OnSharedValueChange(DatabaseModel value)
        {
        }

        protected virtual void OnPropertyChanged(DatabaseModel propertyName)
        {
            LoadExcelData(propertyName);
             PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName.DBName));
        }

        protected virtual void OnPropertyChangedFilterChanges(ToleranceFilter propertyName)
        {
            LoadExcelFilterData(propertyName);
            PropertyChangedFilterChanges?.Invoke(this, new PropertyChangedEventArgs(propertyName.ToleranceName));
        }
    }
}
