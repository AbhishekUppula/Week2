﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ToleranceTask.Models;

namespace ToleranceTask.ViewModels
{
    public class SharedDataService
    {
        private DatabaseModel _sharedValue;

        public DatabaseModel SharedValue
        {
            get { return _sharedValue; }
            set
            {
                _sharedValue = value;
                // Notify subscribers that the shared value has changed
                OnSharedValueChanged?.Invoke(value);
            }
        }

        public event Action<DatabaseModel> OnSharedValueChanged;

    }
}
