﻿using IronXL;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using ToleranceTask.Models;
using ToleranceTask.Views;

namespace ToleranceTask.ViewModels
{
    public class ToleranceFilterModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public event PropertyChangedEventHandler PropertyChangedstatus;
        public event PropertyChangedEventHandler PropertyChangedds;

        public ObservableCollection<ToleranceName> Items { get; set; }

        public ObservableCollection<Status> StatusItems { get; set; }

        public ObservableCollection<DesignSolution> DSItems { get; set; }

        public RelayCommand CloseCommand { get; private set; }

        public ICommand OpenGridWindowCommand { get; }

        public ToleranceFilterModel()
        {
            OpenGridWindowCommand = new RelayCommand(OpenGridWindow);
            CloseCommand = new RelayCommand(Close);
            LoadTolerancenames();
        }

        private void Close()
        {
            // Closing logic here
            Application.Current.Shutdown();
        }

        private void OpenGridWindow()
        {
            ToleranceFilter toleranceFilter = new ToleranceFilter();
            toleranceFilter.ToleranceName = SelectedItem!= null ? SelectedItem.Name: "";
            toleranceFilter.StatusName = statusSelectedItem != null ? statusSelectedItem.Name:"";
            toleranceFilter.DSName = dsSelectedItem != null ? dsSelectedItem.Name: "";

            var secondViewModel = new ToleranceViewModel();
            secondViewModel.TolerranceFilter = toleranceFilter;


            var newWindow = new MainWindow();
            newWindow.DataContext = secondViewModel;
            newWindow.Show();
        }

        public void LoadTolerancenames()
        {
            string filePath = "ToleranceTaskDB/Tolerance.xlsx";

            Items = new ObservableCollection<ToleranceName>();

            WorkBook workBook = WorkBook.Load(filePath);
            WorkSheet workSheet = workBook.WorkSheets[0];

            List<string> lstdsNames = new List<string>();
            List<string> lstUniquedsNames = new List<string>();
            List<string> lstStatus = new List<string>();
            List<string> lstUniqueStatus = new List<string>();

            for (int i = 2;i<=51;i++)
            {
                IronXL.Cell Bcell = workSheet["B" + i].First();
                string ToleranceName = Bcell.StringValue;

                Items.Add(new ToleranceName { Name = ToleranceName });

                IronXL.Cell Ecell = workSheet["E" + i].First();
                string DSSolution = Ecell.StringValue;
                lstdsNames.Add(DSSolution);

                IronXL.Cell Gcell = workSheet["G" + i].First();
                string StatusNames = Gcell.StringValue;
                lstStatus.Add(StatusNames);

                if (Gcell.StringValue == "Not Started")
                {
                    statusSelectedItem = new Status();
                    statusSelectedItem.Name = Gcell.StringValue;
                }


            }
            DSItems = new ObservableCollection<DesignSolution>();
            StatusItems = new ObservableCollection<Status>();

            lstUniquedsNames = lstdsNames.Distinct().ToList();
            lstUniqueStatus = lstStatus.Distinct().ToList();

            foreach (var item in lstUniquedsNames)
            {
                DSItems.Add(new DesignSolution() { Name = item });
            }
            foreach(var item in lstUniqueStatus)
            {
                StatusItems.Add(new Status() { Name = item });
            }

        }

        protected virtual void OnPropertyChanged(ToleranceName propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName.Name));
        }

        protected virtual void OnPropertyChangedstatus(Status propertyName)
        {
            PropertyChangedstatus?.Invoke(this, new PropertyChangedEventArgs(propertyName.Name));
        }

        protected virtual void OnPropertyChangedds(DesignSolution propertyName)
        {
            PropertyChangedds?.Invoke(this, new PropertyChangedEventArgs(propertyName.Name));
        }

        private ToleranceName _selectedItem;
        public ToleranceName SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                _selectedItem = value;
                OnPropertyChanged(SelectedItem);
            }
        }
        

        ////////////Status
        private Status _statusSelectedItem;
        public Status statusSelectedItem
        {
            get { return _statusSelectedItem; }
            set
            {
                _statusSelectedItem = value;
                OnPropertyChangedstatus(statusSelectedItem);
            }
        }


        /////Desin Solution
        ///
        private DesignSolution _dsSelectedItem;
        public DesignSolution dsSelectedItem
        {
            get { return _dsSelectedItem; }
            set
            {
                _dsSelectedItem = value;
                OnPropertyChangedds(dsSelectedItem);
            }
        }


    }
}
